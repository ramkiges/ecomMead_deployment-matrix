#!/bin/sh
# This script creates an HTML table matrix of deployments
# this script runs in /apps/scripts/env_summary
# git@github.wsgc.com:eCommerce-Mead/deployment-matrix.git
PATH=/bin:/usr/bin:/sbin:/usr/sbin:/usr/local/bin:/apps/mead-tools:/apps:/apps/scripts/env_summary:~/bin

cleanUp() { [[ -e $TMP && -n $TMP ]] && rm -rf $TMP; }
trap cleanUp EXIT

FRONTEND="https://repos.wsgc.com/svn/devops/application/frontend-2.1"
JENKINS_JOBS=git@github.wsgc.com:eCommerce-DevOps/jenkins-jobs.git
JENKINS_URL="https://ecombuild.wsgc.com/jenkins"
MATRIX_REPO=git@github.wsgc.com:eCommerce-Mead/deployment-matrix.git
MFE_MATRIX=git@github.wsgc.com:eCommerce-Mead/mfe-matrix.git
LOGIN="pkqaenv:Ca8tWh33l"
LOG_USER="logview:System@111"
CIUSER="ciuser:F@ll2009"
SVN_USER="ciuser"
SVN_PASS="F@ll2009"
HIST_DAYS=1
TODAY=$(date +'%d/%b/%Y')
BRAND_LIST=$(getbrandlist)
BRAND_COUNT=$(wc -w <<< $BRAND_LIST)

# log sniffing properties
LOG_TAIL=50
LOG_HIDE="heartbeat.html|summary.html|internal dummy connection|akamai-sureroute-test-object|authenticate.html|/admin/|favicon.ico|AEC/index.html|127.0.0.1|robots.txt|index.html|DeploymentMatrix|AppScan|\.env"

TIMEOUT="--connect-timeout 3 --max-time 6"
USER_AGENT="--user-agent DeploymentMatrix"

# stats
COUNT_TOTAL=0
COUNT_CONTENT=0
COUNT_WAR=0
COUNT_AKAMAI_CERT=0
COUNT_WAR_FAIL=0
COUNT_CONTENT_FAIL=0
COUNT_SCHEMA_ERR=0
COUNT_WAR_ERR=0
COUNT_FAIL_UP=0
COUNT_AUTO_DEPLOY=0
COUNT_MFT=0
COUNT_ECM=0
COUNT_SCHEMA_MIX=0

PID=$(ps -ef|grep -i $(basename $0) | egrep -iv "grep|$$|vim|$PPID")
[[ -n $PID ]] && { echo "$PID"; exit 0; }

#ENV_LIST=$(cat $(dirname $0)/environment.list | egrep -iv "#|^$")
#set -x
ENV_LIST="$(get-env-list -e bpv) $(get-env-list -e uat) $(get-env-list -e rgs) $(get-env-list -e qa) $(get-env-list -e perf) $(get-env-list -e int)"
{ set +x; } 2>/dev/null
[[ -n $1 ]] && ENV_LIST=$*

TMP=/home/$LOGNAME/matrix-confluence
FIELDS=$TMP/fields
SITE_ERR="#ff3333"
SCHEMA_ERR="#66ccff"
WAR_ERR="#9999ff"
CONTENT_ERR="#ffcc00"
SEPARATOR="#f2f2f2"
NO_CFG="#e0e0e0"
NO_HOST="#8c8c8c"
FAIL_UP="#cccc00"
ECM_ERR="#e6f3ff"
SCHEMA_MIX="#ffeb99"

COLOR_GOOD="#e6ffe6"
COLOR_FAIL="#ffb3b3"
COLOR_NULL="#e1e1ea"

AUTO_DEPLOY="<ac:emoticon ac:name='green-star'/>"
BLUE_STAR="<ac:emoticon ac:name='blue-star'/>"
SSL_CERT="<ac:emoticon ac:name='yellow-star'/>"
MFT_FLAG="<ac:emoticon ac:name='information'/>"
#<ac:emoticon ac:name="warning"/>

# 
TEAM_ENV=$TMP/team-env

# csv files
HISTORY=$TMP/repo/data/deployment-history.csv
OUTFILE=$TMP/repo/qa-deployment-matrix.html
HOSTS=$TMP/repo/data/hosts.csv
DATA_SCHEMA=$TMP/repo/data/schema.csv

# this is the Confluence space in which the page will reside
DOC_SPACE="ES"
PAGENAME="QA Deployment Matrix"

# jenkins job to run this script
JENKINS_JOB="https://ecombuild.wsgc.com/jenkins/job/generate-deployment-matrix/"

# Confluence constants
basedir="/apps/scripts/env_summary"
cclidir="$basedir/atlassian-cli-3.2.0"
cp $0 $basedir

BailOut() {
	[ -n "$1" ] && echo "Error: $*"
	exit 1
}

HTML() {
	echo "$*" >> $OUTFILE
}

which geturls >/dev/null || echo "Need to install geturls"
GIT_USER=$(grep "email.*=" ~/.gitconfig | awk '{ print $NF }')

[ -z "$ENV_LIST" ] && BailOut "Empty env list"

umask 000
rm -rf $TMP 
mkdir -p $TMP $FIELDS

time git clone -q --depth 1 $MATRIX_REPO $TMP/repo || BailOut "Unable to clone $MATRIX_REPO as $GIT_USER"
cd $TMP/repo || BailOut "Unable to cd to $TMP/repo"

time git clone -q --depth 1 $JENKINS_JOBS $TMP/jobs || BailOut "Unable to clone $JENKINS_JOBS as $GIT_USER"
cd $TMP/jobs || BailOut "Unable to cd to $TMP/jobs"

time git clone -q --depth 1 $MFE_MATRIX $TMP/mfe || BailOut "Unable to clone $MFE_MATRIX as $GIT_USER"
cd $TMP/mfe || BailOut "Unable to cd to $TMP/mfe"

#echo "LOG_TAIL: $LOG_TAIL"
#echo "LOG_HIDE: $LOG_HIDE"
echo "History:  $HIST_DAYS days"
echo "Brands:   $BRAND_LIST"
echo "Outfile:  $OUTFILE"

# clean out old output file
rm -f $OUTFILE

HTML "<!-- $(date) -->" 
HTML
HTML "<h5>This page is dynamically generated every hour - any manual edits will be lost</h5>"
HTML "For MFE deployment info, please see <a href='https://confluence.wsgc.com/display/ES/MFE+Deployment+Matrix'>MFE Deployment Matrix</a>"
HTML "<p/>"
HTML "For Xcadmin (AdminTool) deployment info, please see <a href='https://confluence.wsgc.com/display/ES/AdminTool+%28xcadmin%29+Matrix'>AdminTool (xcadmin) Matrix</a>"

HTML "<table border='1'>"
HTML "  <tr>"
HTML "      <td style='text-align:center' BGCOLOR='$SITE_ERR'><font size='-1'>Down</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>@COUNT_WAR_FAIL@</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>Indicates the site was not reachable</font></td>"
HTML "  </tr>"
HTML "  <tr>"
HTML "      <td style='text-align:center' BGCOLOR='$FAIL_UP'><font size='-1'>Fail/Up</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>@COUNT_FAIL_UP@</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>Indicates the deployer failed but the site is up</font></td>"
HTML "  </tr>"
HTML "  <tr>"
HTML "      <td style='text-align:center' BGCOLOR='$CONTENT_ERR'><font size='-1'>Content Failure</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>@COUNT_CONTENT_FAIL@</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>Indicates a content build/deployment failure</font></td>"
HTML "  </tr>"
HTML "  <tr>"
HTML "      <td style='text-align:center' BGCOLOR='$ECM_ERR'><font size='-1'>No ECM pipeline</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>@COUNT_ECM@</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>Indicates an environment is not part of an ECM publishing pipeline</font></td>"
HTML "  </tr>"
HTML "  <tr>"
HTML "      <td style='text-align:center' BGCOLOR='$SCHEMA_MIX'><font size='-1'>Conent schema Mismatch</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>@COUNT_SCHEMA_MIX@</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>Indicates the DP schema does not match the content schema</font></td>"
HTML "  </tr>"
#HTML "  <tr>"
#HTML "      <td style='text-align:center' BGCOLOR='$SCHEMA_ERR'><font size='-1'>Schema/Config Mismatch</font></td>"
#HTML "      <td style='text-align:left'><font size='-1'>@COUNT_SCHEMA_ERR@</font></td>"
#HTML "      <td style='text-align:left'><font size='-1'>Indicates the running schema does not match what is configured</font></td>"
#HTML "  </tr>"
#HTML "  <tr>"
#HTML "      <td style='text-align:center' BGCOLOR='$WAR_ERR'><font size='-1'>War/Config Mismatch</font></td>"
#HTML "      <td style='text-align:left'><font size='-1'>@COUNT_WAR_ERR@</font></td>"
#HTML "      <td style='text-align:left'><font size='-1'>Indicates the running war does not match what is configured</font></td>"
#HTML "  </tr>"
HTML "  <tr>"
HTML "      <td style='text-align:center'><font size='-1'>$AUTO_DEPLOY</font></td>"
HTML "      <td style='text-align:left' bgcolor='$SEPARATOR'><font size='-1'>&nbsp;</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>Indicates deployer is auto-scheduled</font></td>"
HTML "  </tr>"
HTML "  <tr>"
HTML "      <td style='text-align:center'><font size='-1'>$SSL_CERT</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>@COUNT_AKAMAI_CERT@</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>Indicates environment has Akamai SSL certificate</font></td>"
HTML "  </tr>"
HTML "  <tr>"
HTML "      <td style='text-align:center'><font size='-1'>$MFT_FLAG</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>@COUNT_MFT@</font></td>"
HTML "      <td style='text-align:left'><font size='-1'>Indicates environment is deployed via manifest</font></td>"
HTML "  </tr>"
HTML "</table>"
HTML

HTML "<table border='1'>"
HTML "  <tr>"
HTML "      <th style='text-align:center' colspan='2'>Environment</th>"
for b in $BRAND_LIST
do
  HTML "      <th style='text-align:center'>$(tr '[:lower:]' '[:upper:]' <<< $b)</th>"
done
HTML "  </tr>"

for env in $ENV_LIST
do
    echo
    echo "***"
    echo "Environment: $env"
    git stash -q
    git pull -q --rebase 
    git stash pop -q >/dev/null 2>&1

    TEAM=$(ls -1 $TMP/jobs | grep "deploy-$env-" | sed -es/"deploy-$env-"//g)
    #[[ -z $TEAM ]] && TEAM="(unknown)"

    # for some teams, the email address doesn't match the team name
    case $(echo "$TEAM" | tr "A-Z" "a-z") in
        available ) 
            EMAIL="ecomMead@wsgc.com"
        ;;
        release-env ) 
            EMAIL=
        ;;
        brand-team ) 
            EMAIL=
        ;;
        enterpriseqa ) 
            EMAIL=
        ;;
        production-support ) 
            EMAIL=
        ;;
        * ) 
            EMAIL="ecom${TEAM}@wsgc.com" 
            GHE_ORG=ecommerce-$TEAM
        ;;
    esac

    if [[ -n $EMAIL ]]
    then
        MAILTO="<a href='mailto:$EMAIL'>$TEAM</a>"
    else
        MAILTO=$TEAM
    fi
    MAILTO="<font size='-1'>$MAILTO</font>"
    echo "Team: $TEAM - $EMAIL $MAILTO"
    echo

    echo "eCommerce-$TEAM $env" >> $TEAM_ENV

    [[ -n $TEAM ]] && VIEW="$JENKINS_URL/view/deploy-$env-$TEAM" || VIEW="$JENKINS_URL/view/deploy-$env"
    echo "View: $VIEW"

    echo
    echo ">>> Site/Market ${env}"
    HTML
    HTML "  <tr>"
    HTML "      <td rowspan='10' style='text-align:center'>"
    HTML "        <b><font size='-1'><br>&nbsp;</br><a href='$VIEW'>$(echo $env | tr 'a-z' 'A-Z')</a><br>&nbsp;</br><br>$MAILTO</br></font></b>"
    HTML "      </td>"

    HTML
    HTML "      <td style='text-align:center'><b><font size='-1'>Market</font></b></td>"
    DATA=$TMP/repo/data/schema.csv
    for b in $BRAND_LIST
    do
        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        #echo "POM:$POM"
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }
        
        LINE=
        BGCOLOR=

        #set -x
        INFO=$(grep -i ",${env},${b}" $DATA | tail -1)
        #{ set +x; } 2>/dev/null
        echo "INFO: $INFO"

        siteid=$(getsiteid $b $env)
        market=$(getmarket $b $env)

        HTML "      <td style='text-align:center' bgcolor='$BGCOLOR'><font size='-1'>$market $siteid</font></td>"
    done
    HTML "  </tr>"
    HTML

    echo
    echo ">>> Schema ${env}"
    HTML
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>Schema:SID</font></b></td>"
    DATA=$TMP/repo/data/schema.csv
    for b in $BRAND_LIST
    do
        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        #echo "POM:$POM"
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }
        
        LINE=
        BGCOLOR=
        DOMAIN=$(getdomain $b)
        #set -x
        INFO=$(grep -i ",${env},${b}" $DATA | tail -1)
        #{ set +x; } 2>/dev/null
        echo "INFO: $INFO"

        #data_date=$(echo "$INFO" | awk -F, '{ print $1 }')
        schema_cfg=$(echo "$INFO" | awk -F, '{ print $4 }')
        schema_dep=$(echo "$INFO" | awk -F, '{ print $5 }')
        schema_sid=$(echo "$INFO" | awk -F, '{ print $6 }')
        { set +x; } 2>/dev/null

        # detect whether it's in the manifest or not
        #set -x
        MFT=$(grep -i "trigger-ManifestDeployer" $TMP/jobs/deploy-$env-*/deploy-$env-$b*.xml)
        [[ -n $MFT ]] && { MFT=$MFT_FLAG; COUNT_MFT=$(expr $COUNT_MFT + 1); } 
        { set +x; } 2>/dev/null

        echo "$b Schema: configured: $schema_cfg  deployed: $schema_dep "
        [[ -n $schema_dep && $schema_cfg != $schema_dep ]] && { BGCOLOR="$SCHEMA_ERR"; COUNT_SCHEMA_ERR=$(expr $COUNT_SCHEMA_ERR + 1); }
        [[ -n $schema_sid ]] && LINE="$schema_cfg:$schema_sid" || LINE="$schema_cfg"
        HTML "      <td style='text-align:center' bgcolor='$BGCOLOR'><font size='-1'>$LINE $MFT</font></td>"
        echo "$schema_cfg" > $FIELDS/$env-$b.schema
    done
    HTML "  </tr>"
    HTML

    HTML
    echo
    echo ">>> War ${env}"
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>War</font></b></td>"
    DATA=$TMP/repo/data/war.csv
    for b in $BRAND_LIST
    do
        BGCOLOR=
        AUTO=
        AKAMAI_CERT=
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml

        # if the config doesn't exist, just print an empty cell
        svn cat $POM >/dev/null 2>&1 || { HTML "<td  bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }

        INFO=$(grep -i ",${env},${b}" $DATA | sort -u | tail -1)
        echo "INFO: $INFO"
        AKAMAI_CERT=$(echo "$INFO" | awk -F, '{ print $4 }')
        AUTO_TIME=$(echo "$INFO" | awk -F, '{ print $5 }')
        war_deploy=$(echo "$INFO" | awk -F, '{ print $6 }')
        war_version=$(echo "$INFO" | awk -F, '{ print $7 }')
        war_name_cfg=$(echo "$INFO" | awk -F, '{ print $8 }')
        war_name_dep=$(echo "$INFO" | awk -F, '{ print $9 }')
        war_job=$(echo "$INFO" | awk -F, '{ print $10 }')
        war_status=$(echo "$INFO" | awk -F, '{ print $11 }')
        http_code=$(echo "$INFO" | awk -F, '{ print $12 }')

        # if the war deploy failed but the site is up
        summary="https://$host.wsgc.com/summary.html"
        [[ -n $host ]] && http_code=$(curl --fail $TIMEOUT $USER_AGENT -u "$LOGIN" -sk -o /dev/null -w '%{http_code}\n' -k -f "$summary")

        [ -z "$war_version" ] && war_version="&nbsp;"

        # save off these values 
        echo "$war_deploy" > $FIELDS/$env-$b.deploy-war
        echo "$war_name_dep" > $FIELDS/$env-$b.war
        echo "$war_name_cfg" > $FIELDS/$env-$b.cfg

        [[ -n $AUTO_TIME ]] && AUTO="&nbsp;$AUTO_DEPLOY"
        [[ -n $AKAMAI_CERT ]] && { AKAMAI_CERT="&nbsp;$SSL_CERT"; COUNT_AKAMAI_CERT=$(expr $COUNT_AKAMAI_CERT + 1); }
        #[[ $war_name_dep != $war_name_cfg ]] && { BGCOLOR="$WAR_ERR"; COUNT_WAR_ERR=$(expr $COUNT_WAR_ERR + 1); }
        echo "war_status: $war_status [$war_name_dep]"

#set -x
        if [[ $war_status =~ fail || -z $war_name_dep ]] 
        then
          last=$(grep -i ",${env},${b}," $HISTORY 2>/dev/null | tail -1 | awk -F\, '{ print $1 }')
          war_name_dep="<i><b>$last</b></i>"
          COUNT_WAR_FAIL=$(expr $COUNT_WAR_FAIL + 1)
          BGCOLOR="$SITE_ERR"

          if [[ $http_code = 200 ]]
          then 
            BGCOLOR=$FAIL_UP
            COUNT_FAIL_UP=$(expr $COUNT_FAIL_UP + 1)
            COUNT_WAR_FAIL=$(expr $COUNT_WAR_FAIL - 1)
          fi
        else
            last=$(date +'%Y-%m-%d %H:%M')
        fi
 { set +x; } 2>/dev/null
        HTML "      <td style='text-align:center' bgcolor='$BGCOLOR'><a href='$JENKINS_URL/job/$war_job' title='Last Build: $war_deploy'>$war_name_dep</a>$AUTO$AKAMAI_CERT</td>"

        echo "$b war: cfg:$war_name_cfg dep:$war_name_dep   version: $war_version    $BGCOLOR"
        echo "$last" > $FIELDS/$env-$b.last
    done
    HTML "  </tr>"

    # content
    echo
    echo ">>> Content ${env}"
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>Content</font></b></td>"
    DATA=$TMP/repo/data/content.csv
    for b in $BRAND_LIST
    do
        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }
        
        BGCOLOR=
        AUTO=
        generation=
        #set -x
        INFO=$(grep -i ",${env},${b}" $DATA | tail -1)
        { set +x; } 2>/dev/null

        content=$(echo "$INFO" | awk -F, '{ print $4 }')
        content_deploy=$(echo "$INFO" | awk -F, '{ print $5 }')
        status=$(echo "$INFO" | awk -F, '{ print $6 }')
        generation=$(echo "$INFO" | awk -F, '{ print $7 }')
        content_job=$(echo "$INFO" | awk -F, '{ print $8 }')
        AUTO_TIME=$(echo "$INFO" | awk -F, '{ print $9 }')
        [ -n "$AUTO_TIME" ] && AUTO="&nbsp;$AUTO_DEPLOY" || AUTO=
        #bgb=$(echo "$INFO" | awk -F, '{ print $10 }')

        [[ $status =~ FAIL ]] && { BGCOLOR="$CONTENT_ERR"; COUNT_CONTENT_FAIL=$(expr $COUNT_CONTENT_FAIL + 1); }

        echo "$b Content: $content = $status"
        HTML "      <td style='text-align:center' bgcolor='$BGCOLOR'>"
        #HTML "        <a href='$JENKINS_URL/job/$content_job' title='Last Build: $content_deploy'>$content</a>$AUTO<br>$generation <font size='-1'><i>$bgb</i></font></br>"
        HTML "        <a href='$JENKINS_URL/job/$content_job' title='Last Build: $content_deploy'>$content</a>$AUTO"
        HTML "      </td>"
        echo "$content" > $FIELDS/$env-$b.content
#set -x
{ set +x; } 2>/dev/null
    done
    HTML "  </tr>"

    # WCM
    echo
    echo ">>> CAT generation ${env}"
    HTML
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>WCM</font></b></td>"
    DATA=$TMP/repo/data/content.csv
    for b in $BRAND_LIST
    do
        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }
        
        BGCOLOR=
        INFO=$(grep -i ",${env},${b}" $DATA | tail -1)
        generation=$(echo "$INFO" | awk -F, '{ print $7 }')
        wcm=$(echo "$INFO" | awk -F, '{ print $13 }')
        [[ -n $wcm ]] && wcm="<font color='#009933'><i>$wcm</i></font>"

        echo "$b CAT: $generation"
        HTML "      <td style='text-align:center' bgcolor='$BGCOLOR'>"
        HTML "        <font size='-1'>$generation $wcm</font>"
        HTML "      </td>"

        echo "$generation" > $FIELDS/$env-$b.generation
    done
    HTML "  </tr>"

    # BGB
    echo
    echo ">>> CMX ${env}"
    HTML
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>CMX</font></b></td>"
    DATA=$TMP/repo/data/content.csv
    for b in $BRAND_LIST
    do
        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }
        
        BGCOLOR=
set -x
        INFO=$(grep -i ",${env},${b}" $DATA | tail -1)
{ set +x; } 2>/dev/null
        bgb=$(echo "$INFO" | awk -F, '{ print $10 }')
        cmx=$(echo "$INFO" | awk -F, '{ print $11 }')
        [[ $cmx =~ uat1 ]] && cmx= || cmx=" ($cmx)" 

        schema_dp=$(grep -i ",${env},${b}" $DATA_SCHEMA | tail -1 | awk -F, '{ print $4 ":" $6 }' | sed 's/^[ \t]*//;s/[ \t]*$//')
        schema_bgb=$(grep -i ",${env},${b}" $DATA_SCHEMA | tail -1 | awk -F, '{ print $9 }' | sed 's/^[ \t]*//;s/[ \t]*$//')
        schema_svc=$(grep -i ",${env},${b}" $DATA_SCHEMA | tail -1 | awk -F, '{ print $10 }' | sed 's/^[ \t]*//;s/[ \t]*$//')
        # we're not going to compare schema_svc for now, because DB synonyms are picking up the slack and making things work even when mismatched
#set -x
        [[ $schema_dp != $schema_bgb ]] && { BGCOLOR=$SCHEMA_MIX; COUNT_SCHEMA_MIX=$(expr $COUNT_SCHEMA_MIX + 1); }
{ set +x; } 2>/dev/null

        echo "$b bgb/cmx=$bgb/$cmx [dp=$schema_dp|bgb=$schema_bgb|svc=$schema_svc]"
        HTML "      <td style='text-align:center' bgcolor='$BGCOLOR'>"
        HTML "        <font size='-1'>$bgb$cmx</font>"
        HTML "      </td>"
    done
    HTML "  </tr>"

    # ECM
    echo
    echo ">>> ECM Sources ${env}"
    HTML
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>ECM</font></b></td>"
    DATA=$TMP/repo/data/content.csv
    for b in $BRAND_LIST
    do
        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }
        
        BGCOLOR=
        INFO=$(grep -i ",${env},${b}" $DATA | tail -1)
        ecm=$(echo "$INFO" | awk -F, '{ print $12 }')
        [[ -z $ecm ]] && { BGCOLOR=$ECM_ERR; COUNT_ECM=$(expr $COUNT_ECM + 1); }

        schema_dp=$(grep -i ",${env},${b}" $DATA_SCHEMA | tail -1 | awk -F, '{ print $4 ":" $6 }' | sed 's/^[ \t]*//;s/[ \t]*$//')
        schema_ecm=$(grep -i ",${env},${b}" $DATA_SCHEMA | tail -1 | awk -F, '{ print $9 }' | sed 's/^[ \t]*//;s/[ \t]*$//')
        [[ -n $ecm && $schema_dp != $schema_ecm ]] && { BGCOLOR=$SCHEMA_MIX; COUNT_SCHEMA_MIX=$(expr $COUNT_SCHEMA_MIX + 1); }

        echo "$b ecm: $ecm [dp=$schema_dp|ecm=$schema_ecm]"
        HTML "      <td style='text-align:center' bgcolor='$BGCOLOR'>"
        HTML "        <font size='-1'>$ecm</font>"
        HTML "      </td>"
    done
    HTML "  </tr>"

    HTML
    echo
    echo ">>> Deployments ${env}"
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>Updated</font></b></td>"
    DATA=$TMP/repo/data/deployment.csv
    for b in $BRAND_LIST
    do
        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }
        BGCOLOR=

        #set -x
        INFO=$(grep -i ",${env},${b}" $DATA | tail -1)
        #{ set +x; } 2>/dev/null
        updated=$(echo "$INFO" | awk -F, '{ print $4 }')

        #echo "Updated: $updated"
        HTML "      <td style='text-align:center' bgcolor='$BGCOLOR'>$updated</td>"
        echo "$updated" > $FIELDS/$env-$b.updated
    done
    HTML "  </tr>"

    # latest log entries
    echo ">>> Access ${env}"
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>Access</font></b></td>"
    DATA=$TMP/repo/data/access.csv
    for b in $BRAND_LIST
    do
        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }
        
        #set -x
        INFO=$(grep -i ",${env},${b}" $DATA | sort -u | tail -1)
        { set +x; } 2>/dev/null
        echo "INFO: $INFO"

        LAST_HIST_DATE=$(echo "$INFO" | awk -F, '{ print $4 }')
        LAST_HIST_HITS=$(echo "$INFO" | awk -F, '{ print $5 }')
        LAST_HIST_UNIQ=$(echo "$INFO" | awk -F, '{ print $6 }')
        HOST=$(echo "$INFO" | awk -F, '{ print $7 }')
        echo "Last: $b $LAST_HIST_DATE $LAST_HIST_HITS accesses, $LAST_HIST_UNIQ IPs" 
        #HTML "      <td style='text-align:center'><a href='https://$LOG_USER@$HOST:38666/httpd/$b-access.log' title='Hits: $LAST_HIST_HITS IPs: $LAST_HIST_UNIQ'>$LAST_HIST_DATE</a></td>"
        #HTML "      <td style='text-align:center'><a href='https://$LOG_USER@$HOST:38666' title='Hits: $LAST_HIST_HITS IPs: $LAST_HIST_UNIQ'>$LAST_HIST_DATE</a></td>"
        HTML "      <td style='text-align:center'><a href='https://$HOST:38666' title='Hits: $LAST_HIST_HITS IPs: $LAST_HIST_UNIQ'>$LAST_HIST_DATE</a></td>"
    done
    HTML "  </tr>"

    # MFE build status
    echo ">>> MFE ${env}"
    link="<a href='https://ecombuild.wsgc.com/jenkins/job/config-$env-mfe/'>MFE Build</a>"
    HTML "  <tr>"
    HTML "      <td style='text-align:center'><b><font size='-1'>$link</font></b></td>"
    DATA=$TMP/mfe/data/mfe-build-stats.csv
    for b in $BRAND_LIST
    do
        COLOR=

        # if the config doesn't exist, just print an empty cell
        POM=$FRONTEND/qa/config/app/trunk/$b/$env/pom.xml
        svn cat $POM >/dev/null 2>&1 || { HTML "<td bgcolor='$NO_CFG'>&nbsp;</td>"; continue; }
        host=$(grep -i ",${env},${b}" $DATA | tail -1)
        [[ -z $host ]] && host=$(get-host $b $env 2>/dev/null | awk -F\. '{ print $1 }')
        [[ -z $host ]] && { HTML "<td  bgcolor='$NO_HOST'>&nbsp;</td>"; continue; }

        #set -x
        status=$(grep -i "^$env,.*$b" $DATA | sort -u | tail -1 | awk -F, '{ print $5 }' | awk '{ print $1 }')
        { set +x; } 2>/dev/null
        echo "$env $b $status"

        if [[ -z $status ]]
        then 
          COLOR=$COLOR_NULL 
          status=
        fi

        if [[ $status =~ fail ]]
        then 
          COLOR=$COLOR_FAIL
          #set -x
          DATE=$(grep -i "^$env,.*,success,.*$b" $DATA | sort -u | tail -1 | awk -F, '{ print $2 }')
          { set +x; } 2>/dev/null
          status=$DATE
        fi

        if [[ $status =~ succ ]]
        then
          COLOR=$COLOR_GOOD
          status=
        fi

        HTML "    <td bgcolor='$COLOR' style='text-align:center'><font size='-1'>$status</font></td>"
    done
    HTML "  </tr>"

    HTML
    HTML "<tr>"
    HTML "  <td colspan='$(expr $BRAND_COUNT + 2)' bgcolor='$SEPARATOR'><font size='-5'>&nbsp;</font></td>"
    HTML "</tr>"

    echo
    # update git repo with the latest value
    for b in $BRAND_LIST
    do
        last=$(cat $FIELDS/$env-$b.last 2>/dev/null)
        content=$(cat $FIELDS/$env-$b.content 2>/dev/null)
        generation=$(cat $FIELDS/$env-$b.generation 2>/dev/null)
        war=$(cat $FIELDS/$env-$b.war 2>/dev/null)
        cfg=$(cat $FIELDS/$env-$b.cfg 2>/dev/null)
        schema=$(cat $FIELDS/$env-$b.schema 2>/dev/null)
        updated=$(cat $FIELDS/$env-$b.updated 2>/dev/null)
        deploy_war=$(cat $FIELDS/$env-$b.deploy-war 2>/dev/null)
        deploy_content=$(cat $FIELDS/$env-$b.deploy-content 2>/dev/null)
        access=$(cat $FIELDS/$env-$b.access 2>/dev/null)
        UPDATE="$last,$env,$b,$schema,$TEAM,$cfg,$war,$content,$updated,$deploy_war,$deploy_content,$access,$generation" 
        echo "data: $UPDATE"
        echo "$UPDATE" >> $HISTORY
    done

    HTML

    #break

done

HTML "</table>"

HTML "<p>Team names are derived from the <a href='https://ecombuild.wsgc.com/jenkins/'>Jenkins</a> deployment view names, which should be in the format of <code>deploy</code>-<em>env</em>-<code>team</code>. 
Use the Jenkins job <a href='https://ecombuild.wsgc.com/jenkins/job/jenkins-update-frontend-deploy/'>Update Frontend Deployers</a> <span> </span> to deploy a new branch to a team's environment.</p>"

HTML "<p>Created by <a href='$JENKINS_JOB'>$(basename $JENKINS_JOB)</a></p>"
HTML "<font size='-2'>Generated on $(hostname)</font>"

chmod 777 $OUTFILE
ls -ld $OUTFILE

# update counts
sed -i $OUTFILE \
    -es/@COUNT_AKAMAI_CERT@/$COUNT_AKAMAI_CERT/g \
    -es/@COUNT_WAR_FAIL@/$COUNT_WAR_FAIL/g \
    -es/@COUNT_CONTENT_FAIL@/$COUNT_CONTENT_FAIL/g \
    -es/@COUNT_SCHEMA_ERR@/$COUNT_SCHEMA_ERR/g \
    -es/@COUNT_AUTO_DEPLOY@/$COUNT_AUTO_DEPLOY/g \
    -es/@COUNT_FAIL_UP@/$COUNT_FAIL_UP/g \
    -es/@COUNT_MFT@/$COUNT_MFT/g \
    -es/@COUNT_ECM@/$COUNT_ECM/g \
    -es/@COUNT_SCHEMA_MIX@/$COUNT_SCHEMA_MIX/g \
    -es/@COUNT_WAR_ERR@/$COUNT_WAR_ERR/g 

# only update confluence page if no args were passed in
if [ -z "$1" ]
then
    echo
    # update confluence page
    sh $cclidir/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --action storepage --file $OUTFILE --noConvert --verbose 
    upload=$?
    [[ $upload -eq 0 ]] && rm -rf $OUTFILE || echo "$OUTFILE has a problem"
fi

# commit new new data
echo 
echo "Check in new files"

echo "$HIST_DAYS days of history:"
echo "Last-Working Date,Environment,Brand,Schema,Team,War-Cfg,War-Deployed,Content,Deploy-Date,Last-Access,WCM-Generation" > $HISTORY.new

for e in $(awk -F, '{ print $2 }' $HISTORY | sort -u)
do
  for b in $(grep -i "^20.*,$e," $HISTORY | awk -F, '{ print $3 }' | sort -u)
  do
    grep -i "^20.*,$e,$b," $HISTORY | sort | tail -1 >> $HISTORY.new
  done
done
mv $HISTORY.new $HISTORY

echo "Commit files"
cd $TMP/repo
for file in $HISTORY 
do
    echo " > $file"
    git stash -q
    git pull -q --all --rebase >/dev/null 2>&1
    git stash pop -q >/dev/null 2>&1
    git add $file
    git commit -q -m "update $(date +'%Y-%m-%d %H:%M')" $file
    git push --force
done

rm -rf $TMP
 
if [[ -z $1 ]]
then
    if [ $upload -eq 0 ]
    then
        echo "New page uploaded OK"
        exit 0
    else
        echo "Page didn't upload"
        exit 1
    fi

#    git pull --all >/dev/null 2>&1 
#    git add $TEAM_ENV
#    git commit -m "update" $TEAM_ENV
#    git push --force
#    git pull --all >/dev/null 2>&1
else
    echo "Confluence page not updated"
    exit 0
fi


