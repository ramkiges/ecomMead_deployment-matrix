#!/bin/sh
PATH=/apps/mead-tools:/usr/local/bin:/bin:/usr/bin:/sbin:/usr/sbin
REPO=git@github.wsgc.com:eCommerce-Kubernetes-Bedrock/xcadmin-helm-config.git
TMP=/tmp/xcadmin-matrix

# confluence settings
DOC_SPACE="ES"
CCLIDIR="/apps/scripts/env_summary/atlassian-cli-3.2.0"
PAGENAME="AdminTool (xcadmin) Matrix"

OUTFILE=/tmp/xcadmin.html
rm -f $OUTFILE

BailOut() {
  [[ -n $1 ]] && echo "$(hostname):$(basename $0): $*" >&2
  exit 255
}

HTML() { echo "$*" >> $OUTFILE; }
cleanUp() { [[ -e $TMP && -n $TMP ]] && rm -rf $TMP; }
trap cleanUp EXIT

#rm -rf $TMP
[[ -e $TMP/.git ]] || git clone -q --depth 1 $REPO $TMP

cd $TMP/config || BailOut "Can't cd to $TMP"
git pull -q

DATE=$(date +'%y%m%d')

HTML "<!-- $DATE -->"
HTML "<a href='https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job/ecom/job/xcadmin/'>xcadmin deployers</a>"
HTML "<p/>"
HTML "<a href='https://github.wsgc.com/eCommerce-Kubernetes-Bedrock/xcadmin-helm-config'>xcadmin helm config</a>"

HTML "<table border='1' width='80%'>"
HTML "<tr>"
HTML "  <th style='text-align:center'>Instance</th>"
HTML "  <th style='text-align:center'>Schema</th>"
HTML "  <th style='text-align:center'>Installation</th>"
HTML "  <th style='text-align:center'>Version<br>Configured</br></th>"
HTML "  <th style='text-align:center'>Version<br>Deployed</br></th>"
for b in $(get-brand-list | tr '[:lower:]' '[:upper:]')
do
  HTML "  <th style='text-align:center'>$b</th>"
done
HTML "  <th style='text-align:center'>Market</th>"
HTML "</tr>"
HTML

XCADMIN_LIST=$(find . -maxdepth 1 -type d | egrep -iv "prd|prod|intdev" | sed -es%\./%%g -es%\\.%%g | sort)
for env in $XCADMIN_LIST
do
  BGCOLOR=
  YML=$env/values.yaml
  brands=
  inst=$(yq eval ".appspecProperties.Installation" $YML | grep -iv "null")
  ver_cfg=$(yq eval ".deployment.image.tag" $YML | grep -iv "null")
  url=$(yq eval ".contexts.ROOT.appspecProperties.SecureAppBase" $YML | grep -iv "null")
  ver_dep=$(curl -fsqk $url/summary.html | grep "WAR" | awk -F '[<>]' '{ print $9 }')

  jdbc=$(yq eval "(.rootXml.dbResources[] | select(has(\"name\")) | select(.name == \"jdbc/EcomDB\")).url " $YML | tr '[:upper:]' '[:lower:]' | egrep -iv "null")
  [[ -z $jdbc ]] && jdbc=$(yq eval ".contexts.ROOT.rootXml.dbResources[] | select(has(\"name\")) | select(.name == \"jdbc/EcomDB\").url" $YML | tr '[:upper:]' '[:lower:]' | egrep -iv "null")
  own=$(yq eval ".appspecProperties.TableOwner" $YML | tr '[:upper:]' '[:lower:]' | egrep -iv "null")
  sid=$(awk -F/ '{ print $NF }' <<< $jdbc)
  [[ -z $sid ]] && exit

  # this crap is because the s/d names don't match the instance names
  case $env in
    veqa* ) sd_env=$env ;;
    *     ) sd_env=${env}_allroles ;;
  esac
  sd=https://ecombuild.wsgc.com/jenkins/job/k8s-deployers/job/ecom/job/xcadmin/job/$sd_env/
  #status=$(curl -sqk $sd/lastBuild/api/json?tree=result | jq -r .result 2>/dev/null | tr "[:upper:]" "[:lower:]")
  #[[ $status =~ fail ]] && BGCOLOR='#ff6666'
  #[[ $status =~ succ ]] && BGCOLOR='#99ffd6'
  status=$(curl -fsqk $url/summary.html | grep "WAR" | awk -F '[<>]' '{ print $9 }')
  [[ -n $status ]] && BGCOLOR='#99ffd6' || BGCOLOR='#ff6666'

  HTML
  HTML "<tr>"
  HTML "  <td bgcolor='$BGCOLOR'><a href='$url'>$env</a></td>"
  HTML "  <td>$own:$sid</td>"
  HTML "  <td>$inst</td>"
  HTML "  <td>$ver_cfg</td>"
  HTML "  <td>$ver_dep</td>"

  for b in $(getbrandlist)
  do
    s=$(yq eval ".contexts.${b}.appspecProperties.SiteId" $YML | grep -iv "null")

    HTML "  <td style='text-align:center'>"
    [[ -z $s ]] && HTML "&nbsp;" || HTML "<ac:emoticon ac:name='tick'/>"
    HTML "  </td>"

    #yq eval ".contexts.${b}" $YML 

    [[ $s =~ ^6 ]] && market=US
    [[ $s =~ ^7 ]] && market=CAN
    brands="$brands $b "
  done

  HTML "  <td>$market</td>"
  HTML "</tr>"

  #echo "$env,$market,$own:$sid,$inst,$brands"
done

HTML "</table>"

sh $CCLIDIR/confluence.sh --space "$DOC_SPACE" --title "$PAGENAME" --action storepage --file $OUTFILE --noConvert --verbose || BailOut "Confluence update failed"

#rm -f $OUTFILE

